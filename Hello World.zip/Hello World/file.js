const fs = require('fs');
const os = require('os');

console.log(os.cpus().length);

//sync (blocking)
// fs.writeFileSync('hello.txt', 'Hello, World!');

//async(non blocking)
// fs.writeFile('hello.txt', 'Hello, World!', (err) => {
//     if (err) throw err;
// })

// read file

console.log(1);

//blocking
// const file = fs.readFileSync('hello.txt', 'utf8');
// console.log(file);

//non blocking
// fs.readFile('hello.txt', 'utf8', (err, data) => {
//     if (err) throw err;
//     console.log(data);
// })

console.log(2);
console.log(3);

