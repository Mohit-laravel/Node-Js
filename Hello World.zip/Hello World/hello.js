const math = require("./math.js");

console.log(math.add(2, 3));
console.log(math.subtract(4, 3));
